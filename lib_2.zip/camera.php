<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Camera Page</title>
    <script>
        function disableButton() {
            var button = document.getElementById('myButton');
            button.disabled = true;
            button.innerHTML = 'Starting...';
        }
    </script>
    <style>
        /* Body styling */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: linear-gradient(135deg,rgb(3, 119, 119),rgb(32, 145, 145),rgb(5, 134, 89));
            color: #97FEED;
            overflow: hidden;
        }

        /* Container styling */
        .container {
            text-align: center;
            background: rgba(255, 255, 255, 0.1);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            backdrop-filter: blur(10px);
        }

        .container h1 {
            font-size: 2.5rem;
            margin-bottom: 10px;
            color: #ffffff;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }

        .container p {
            font-size: 1.2rem;
            margin-bottom: 20px;
            color: #dcdcdc;
        }

        /* Button styling */
        button {
            padding: 12px 25px;
            background: linear-gradient(135deg, #1f8ef1, #5a8dee);
            color: #0B666A;
            font-size: 16px;
            font-weight: bold;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        button:hover {
            background: linear-gradient(135deg, #00c6ff, #0072ff);
            transform: translateY(-3px);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.3);
        }

        button:disabled {
            background: #999;
            cursor: not-allowed;
            box-shadow: none;
        }

        /* Animation effect */
        @keyframes glow {
            0% {
                box-shadow: 0 0 5px rgba(255, 255, 255, 0.2);
            }

            50% {
                box-shadow: 0 0 20px rgba(255, 255, 255, 0.4);
            }

            100% {
                box-shadow: 0 0 5px rgba(255, 255, 255, 0.2);
            }
        }

        button:hover {
            animation: glow 1.5s infinite alternate;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Welcome to the Camera Page</h1>
        <p>Click the start button only once</p>
        <form method="post">
            <button type="submit" id="myButton" onclick="disableButton()" name="action">Start</button>
            <button type="submit" name="quit">Quit</button>
        </form>
    </div>
</body>

</html>