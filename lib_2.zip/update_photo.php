<?php
$userid = $_GET["userid"];
echo "<script>var userid='$userid';</script>";
if (isset($_POST['date'])) {
    header("Location:date.php?userid=" . $userid);
}
if (isset($_POST['database'])) {
    header("Location:database.php?userid=" . $userid);
}
if (isset($_POST['today'])) {
    header("Location:today.php?userid=" . $userid);
}

if (isset($_POST["about"])) {
    header("Location:about.php?userid=" . $userid);
}

$conn = mysqli_connect('localhost', 'root', 'mohan 123.', 'library');
$query = "SELECT * FROM department";
$result = mysqli_query($conn, $query);
$ids = array();
while ($row = mysqli_fetch_assoc($result)) {
    $ids[] = $row["id"];
}
$message = "";
$color = "red";
if (isset($_POST['submit'])) {
    $regno = $_POST["regno"];
    $photo = addslashes(file_get_contents($_FILES['photo']['tmp_name']));
    if (!$conn) {
        echo "Error: Unable to connect DBServer";
    } else {
        $query = "UPDATE students SET photo='$photo' where regno='$regno' ";
        try {
            $execute = mysqli_query($conn, $query);
            $message = "RegNo. " . $regno . " updated with New Photo";
            $color = "green";
        } catch (Exception $e) {
            if ($e->getCode() == 1062)
                $message = "Already registered";
            else
                $message = $e;
            $color = "red";
        }
    }
}

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Current_day</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="./todaypage.css">

</head>


<body onload="initClock">

    <div class="wrapper">
        <header class="header">
            <div class="text">GIT Central Library Attendance Management
            </div>
            <div class="datetime">
                <div class="day">
                    <div id="time">
                        <h2 id="current-time">12:00:00</h2>
                    </div>
                    <span id="dayname">day</span>
                    <span id="month">month</span>
                    <span id="daynum">num</span>
                    <span id="year">year</span>
                </div>
            </div>

        </header>
        <article>
            <div class="admin">
                <h1>Update Photo </h1>

                <!--div class="dropdown">
                    <i class="fa-solid fa-ellipsis-vertical"></i>
                    <div class="dropdown-content">
                        <form method="post">
                        <button name="addStudent" >Add Student</button>
                        <button>Option 2</button>
                        <button>Option 3</button>
                    </form>
                    </div>
                </div-->
            </div>
            <script>
                function viewDept(id) {
                    window.location = "student.php?userid=" + userid + "&department=" + id;
                }
            </script>
            <div class='table-container'>


                <div class="container">
                    <form id="myForm" method="post" enctype="multipart/form-data">
                        <label for="regno">Reg No:</label>
                        <input type="text" id="regno" name="regno" required>

                        <br>
                        <label for="photo">Photo:</label>
                        <input type="file" id="photo" name="photo" accept="image/png, image/jpeg, image/webp, image/jpg" required>
                        <br>
                        <?php
                        echo " <p class = 'message'> " . $message . "</p>";
                        ?>
                        <br>
                        <button type="submit" name="submit" class = "submit">Submit</button>
                    </form>
                </div>
                <script>
                    document.getElementById('myForm').addEventListener('submit', function(event) {
                        var regno = document.getElementById('regno').value;
                        var name = document.getElementById('name').value;
                        var photo = document.getElementById('photo').value;

                        if (!regno || !name || !photo) {
                            alert('Please fill in all fields');
                            event.preventDefault();
                        }
                    });
                </script>

            </div>

        </article>
        <form method="post">
            <aside>
                <h1 style="text-align: center;" id="menu">MENU</h1><br>
                <nav class="menu">
                    <button style="width: 100%;" name="today">
                        <h2><i class="fa-solid fa-calendar-week"></i> Today </h2>
                    </button>
                    <button style="width: 100%;" name="date">
                        <h2><i class="fa-solid fa-calendar-days"></i> Print Attendance</h2>
                    </button>
                    <button style="width: 100%;" class="current" name="database">
                        <h2><i class="fa-solid fa-database"></i> DataBase</h2>
                    </button>
                </nav>
        </form>
        <div class="user">
            <p>@<?php echo $userid ?></p>
        </div>
        <form method="post">
            <div class="info">


                <button name="about"> <i class="fa-solid fa-circle-info"></i></button>
            </div>
        </form>
        </aside>
    </div>

    <script>
        let time = document.getElementById("current-time");
        setInterval(() => {
            let d = new Date();
            time.innerHTML = d.toLocaleTimeString();
        })
    </script>



    <script type="text/javascript">
        function updateClock() {
            var now = new Date();
            var dname = now.getDay(),
                months = now.getMonth(),
                date = now.getDate(),
                year = now.getFullYear();

            var month = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
            var weeks = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
            var ids = ["dayname", "month", "daynum", "year"];
            var values = [weeks[dname], date, month[months], year];
            for (var i = 0; i < ids.length; i++) {
                document.getElementById(ids[i]).firstChild.nodeValue = values[i];
            }
        }

        function initClock() {
            updateClock();
            window.setInterval(updateClock, 1000);
        }
        initClock(); // call initClock to start the clock
    </script>


</body>
<style>
    * {
        margin: 0;
        padding: 0;
    }

    #csvTextArea {
        display: none;
    }

    .header {
        grid-area: header;
        color: #9EC8B9;
    }

    article {
        grid-area: content;
        background-color: #113946;
        padding: 10px;
    }


    .wrapper {
        display: grid;
        grid-gap: 5px;
        grid-template-columns: 1fr 3fr;
        grid-template-areas:
            "header  header"
            "sidebar content"
            "footer  footer";
    }

    /*----------------------------HEADER-------------------*/
    html {
        background-color: #0B666A;
    }

    .header {
        font-weight: bold;
        display: flex;
        justify-content: space-around;
    }

    .header .text {
        font-size: 40px;
        background-color: #092635;
        padding: 20px;
        border-radius: 5px;
        border: 2px solid #9EC8B9;
        width: 81%;
        text-align: center;
        color: #9EC8B9;
    }

    .datetime {
        border: 2px solid #9EC8B9;
        border-radius: 5px;
        width: 15%;
        text-align: center;
        background-color: #092635;
    }

    #current-time {
        color: white;
        text-align: center;
    }

    #dayname,
    #month,
    #daynum,
    #year {
        color: #9EC8B9;
    }

    /*-----------------------------------------------------------------------SIDEBAR--------------------------------------------------*/
    aside {
        background-color: #092635;
        padding: 20px;
        width: 300px;
        position: relative;
        height: 74vh;
        border: 2px solid #9EC8B9;
        border-radius: 5px;
    }

    h2 {
        color: #092635;
        text-align: left;
        margin-bottom: 20px;
    }

    aside #menu {
        background-color: #1B4242;
        width: 100px;
        text-align: center;
        border-radius: 14px;
        padding: 10px;
        margin: 0 auto;
        margin-bottom: 20px;
        border: 2px solid #9EC8B9;
        text-shadow: 1px 2px 2px darkslategrey;
        color: #9EC8B9;
    }

    p {
        width: 80px;
        border-radius: 7px;
        text-align: center;
        padding: 10px;
        margin: 0 auto;
        margin-top: 20px;
        font-size: 20px;
        color: #35A29F;
    }


    .menu button {
        padding: 10px 20px;
        background-color: #35A29F;
        color: black;
        border: 2px solid #092635;
        border-radius: 10px;
        cursor: pointer;
    }


    .printer:hover {
        transform: scale(1.05);
        transition: background-color 0.3s ease;
        background-color: #35A29F;
    }

    .menu button:hover {
        background-color: #9EC8B9;
        transition: background-color 0.3s ease;
        transform: scale(1.05);
    }

    .menu button.current {
        background-color: #9EC8B9;
        color: black;
    }

    .menu button.current:hover {
        background-color: #9EC8B9;
    }

    .info {

        position: absolute;
        bottom: 10px;
        right: 10px;
    }

    .info button {
        width: 70px;
        padding: 7px;
        padding-left: 10px;
        padding-right: 10px;
        border-radius: 5px;
        border: none;
    }

    .info button:hover {
        background-color: #35A29F;
        transform: scale(1.05);
    }

    article {
        padding: 20px;
        border: 2px solid #9EC8B9;
        border-radius: 5px;
        background-color: #092635;
        height: 74vh;
    }



    .admin {
        background-color: #0B666A;
        color: #97FEED;
        padding: 10px 20px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 20px;
        border-radius: 5px;
        border: 2px solid #97FEED;
        text-transform: uppercase;
    }

    .admin h1 {
        margin: 0;

    }

    .dropdown {
        position: relative;
        display: inline-block;
        text-align: center;
        width: 10px;

    }

    .dropdown i {
        font-size: 24px;
        color: white;
        cursor: pointer;
    }

    .dropdown-content {
        display: none;
        position: absolute;
        top: 100%;
        right: 0;
        background-color: #2e4c56;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        z-index: 10;
        overflow: hidden;
        padding: 10px;
    }

    .dropdown-content form {
        display: flex;
        flex-direction: column;
        margin: 0;
    }

    .dropdown-content button {
        background-color: transparent;
        color: white;
        border: none;
        padding: 10px;
        text-align: left;
        font-size: 14px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    .dropdown-content button:hover {
        background-color: #00d4ff;
        color: #1e3d46;
    }

    .dropdown:hover .dropdown-content {
        display: block;
        position: absolute;
        right: -23px;
    }




    /* Form Container */
    .container {
        width: 100%;
        max-width: 530px;
        padding: 10px;
        background-color: rgb(6, 69, 85);
        border-radius: 10px;
        box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
        color: #00d4ff;
        margin: 0 auto;
        height: 250px;
        border: 1px solid #00d4ff;
        display: flex;
        justify-content: space-between;
        flex-direction: column;
    }


    label {
        font-size: 16px;
        color: #00d4ff;
        margin-bottom: 4px;
        width: 100px;
        border: 1px solid #0B666A;
        padding: 10px;
        border-radius: 5px;
        text-align: left;
        display: inline-block;

    }

    input,
    select {
        padding: 8px;
        border: 1px solid #00d4ff;
        border-radius: 8px;
        background-color: #0B666A;
        color: #00d4ff;
        font-size: 16px;
        text-transform: uppercase;
        width: 400px;
        margin: 10px 0 10px 0;
    }

    input:focus,
    select:focus {
        border-color: #00d4ff;
        outline: none;
    }

    input[type="file"] {
        padding: 4px;
        font-size: 16px;
        border-radius: 8px;
        background-color: #092635;
        border: 2px solid #00d4ff;
    }

    .message {
        color: #00d4ff;
        padding: 5px;
        background-color: #0B666A;
        border: 1px solid #00d4ff;
        border-radius: 5px;
        display: inline-block;
        width: 97%;
        margin: 10px 0 10px 0;
    }

    .submit {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 10px 20px;
        font-size: 16px;
        font-weight: bold;
        text-transform: uppercase;
        color: #0f2027;
        background: linear-gradient(135deg, #00d4ff, #00a6ff);
        border: none;
        border-radius: 5px;
        cursor: pointer;
        transition: all 0.3s ease;
        position: absolute;
        bottom: 30px;
        right: 30px;
        border: none;
    }
</style>

</html>