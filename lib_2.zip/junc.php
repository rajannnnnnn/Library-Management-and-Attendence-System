<?php
$userid = $_GET["userid"];
if (isset($_POST['camera'])) {
    header("Location:camera.php?userid=" . $userid);
}
if (isset($_POST['admin'])) {
    header("Location:today.php?userid=" . $userid);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
</head>
<style>
    * {
        margin: 0;
        padding: 0;

    }

    .container {
        background-image: url("images/back.jpg");
        opacity: 10;
        width: 100vw;
        height: 100vh;
        background-position: center;
        background-size: cover;
        background-repeat: no-repeat;
    }

    figure {
        width: 75px;
        height: 75px;
        background-color: #35A29F;
        padding: 30px;
        display: flex;
        flex-direction: column;
        align-items: center;
        border-radius: 30%;
        border: 5px solid #009990;

    }

    .cap{
        font-weight: bold;
        padding: 3px;
    }

    .camera:hover img, .admin:hover img {
        transform: scale(1.1);
    }

    .camera>img, .admin>img {
        width: 100%;
        height: 100%;
        object-fit: fill;
    }

    h1 {
        color: black;
        font-size: 50px;
        text-align: center;
        font-family: 'Courier New', Courier, monospace;
        letter-spacing: 5px;
        width: 60%;
        background-color: #F0BB78;
        padding-top: 15px;
        padding-bottom: 15px;
        border-bottom-right-radius: 7px;

    }

    .box {
        display: flex;
        justify-content: space-around;
        align-items: center;
        width: 400px;
        height: 150px;
        padding: 50px;
        border-top-left-radius: 30px;
        border-bottom-left-radius: 30px;
        margin: 0 auto;
        margin-top: 10%;
        margin-right: 0px;
        background-color: #0B666A;
        vertical-align: top;
        border: 3px solid #F0BB78;
        border-right: none;

    }

    button{
        border-radius: 50%;
        border: none;
    }

</style>

<body>
    <form method="POST">
        <div class="container">
            <h1>WELCOME TO THE LIBRARY</h1>
            <div class="box">
                <button name="camera">
                    <figure class="camera">
                        <img src="images/camera.svg" alt="">
                        <figcaption class="cap">Camera</figcaption>
                    </figure>
                </button>
                <button name="admin">
                    <figure class="admin">
                        <img src="images/admin.svg" alt="">
                        <figcaption class="cap">Admin</figcaption>
                    </figure>
                </button>
            </div>
        </div>
    </form>
</body>

</html>