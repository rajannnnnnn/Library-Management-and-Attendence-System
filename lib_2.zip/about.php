<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #092635;
            color: #333;
        }

        .container {
            text-align: center;
            padding: 20px;
        }

        h1 {
            font-size: 2.5rem;
            color: #9EC8B9;
            animation: fadeIn 2s ease-in-out;
        }

        .photos {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
            margin-top: 20px;
        }

        .photo {
            border: 2px solid #35A29F;
            width: 200px;
            padding: 20px;
            background: #1B4242;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            cursor: pointer;
        }

        .photo:hover {
            transform: translateY(-10px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
        }

        .photo img {
            border: 1px solid #97FEED;
            width: 100%;
            height: auto;
            border-radius: 10px;
            transition: transform 0.3s ease;
            box-shadow: 2px 2px 3px #35A29F;
        }

        .photo:hover img {
            transform: scale(1.05);
        }

        .photo h2 {
            margin-top: 10px;
            font-size: 1.2rem;
            color: #97FEED;
        }

        .details {
            margin-top: 1px;
            font-size: 1rem;
            color: #35A29F;
            width: 100%;
            background-color: #092635;
            padding: 7px;
            border-radius: 4px;
        }

        .details-container {
            position: fixed;
            top: 0;
            left: 100%;
            width: 100%;
            height: 100%;
            background-color: #092635;
            box-shadow: -4px 0 10px rgba(0, 0, 0, 0.1);
            overflow-y: auto;
            padding: 20px;
            transition: left 0.5s ease;
        }

        .details-container.active {
            left: -10px;
        }

        .details-container h2 {
            font-size: 2rem;
            color: #97FEED;
        }

        .details-container p {
            font-size: 1.2rem;
            margin: 10px 0;
            color: #35A29F;
        }

        .close-btn {
            position: absolute;
            top: 20px;
            right: 50px;
            font-size: 1.5rem;
            color: #fff;
            background-color: #1B4242;
            border: none;
            padding: 10px 17px;
            border-radius: 50%;
            cursor: pointer;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        .close-btn:hover {
            background-color: #35A29F;
            transform: scale(1.1);
        }

        .close-btn:focus {
            outline: 2px solid #97FEED;
            outline-offset: 2px;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }


        .printer {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            text-transform: uppercase;
            color: #0f2027;
            background: linear-gradient(135deg, #00d4ff, #00a6ff);
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s ease;
            position: absolute;
            bottom: 30px;
            right: 30px;
            border: none;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>About Us</h1>
        <div class="photos">
            <div class="photo" data-name="Rajan" data-role="Backend Developer" data-details="Rajan is responsible for the backend development of the project, ensuring robust and scalable server-side logic.">
                <img src="images/rajan.jfif" alt="Rajan">
                <h2>Rajan</h2>
                <p class="details">Role: Backend Developer</p>
            </div>
            <div class="photo" data-name="Mohanraj" data-role="User Interface and Design" data-details="Mohanraj designed the user interface and created an engaging, user-friendly design for the project.">
                <img src="images/mohan.jpg" alt="Mohanraj">
                <h2>Mohanraj</h2>
                <p class="details">Role: UI/Design</p>
            </div>
            <div class="photo" data-name="Rajkumar" data-role="Testing and Setup" data-details="Rajkumar is responsible for testing the project and handling setups to ensure smooth functionality.">
                <img src="images/rajkumar.jpg" alt="Rajkumar">
                <h2>Rajkumar</h2>
                <p class="details">Role: Testing & Setup</p>
            </div>
            <div class="photo" data-name="Rishikanna" data-role="Python Algorithm for Face Recognition" data-details="Rishikanna implemented the Python algorithm for face recognition, enhancing the project's technical depth.">
                <img src="images/rishi.jpg" alt="Rishikanna">
                <h2>Rishikanna</h2>
                <p class="details">Role: Python Algorithm</p>
            </div>
        </div>
    </div>
    <button class="printer">Exit</button>

    <div class="details-container" id="detailsContainer">
        <button class="close-btn" id="closeBtn">&times;</button>
        <h2 id="detailName">Name</h2>
        <p id="detailRole">Role</p>
        <p id="detailDescription">Details</p>
    </div>

    <script>
        const photos = document.querySelectorAll('.photo');
        const detailsContainer = document.getElementById('detailsContainer');
        const closeBtn = document.getElementById('closeBtn');
        const detailName = document.getElementById('detailName');
        const detailRole = document.getElementById('detailRole');
        const detailDescription = document.getElementById('detailDescription');

        photos.forEach(photo => {
            photo.addEventListener('click', () => {
                detailName.textContent = photo.getAttribute('data-name');
                detailRole.textContent = `Role: ${photo.getAttribute('data-role')}`;
                detailDescription.textContent = photo.getAttribute('data-details');
                detailsContainer.classList.add('active');
            });
        });

        closeBtn.addEventListener('click', () => {
            detailsContainer.classList.remove('active');
        });
    </script>
</body>

</html>